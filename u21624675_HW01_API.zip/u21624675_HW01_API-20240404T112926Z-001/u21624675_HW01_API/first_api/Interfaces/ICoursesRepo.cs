﻿using first_api.Models;

namespace first_api.Interfaces
{
    public interface ICoursesRepo
    {
        // Declaring EP
        Task<bool> AddCourse(CourseListing courseListing); // C
        Task<List<CourseListing>> GetAllCourses(); // R
        Task<CourseListing> GetCourse(int courseListingId); // R - one
        Task<bool> UpdateCourse(CourseListing courseListing); // U 
        Task<bool> DeleteCourse(int courseListingId); // D
    }
}

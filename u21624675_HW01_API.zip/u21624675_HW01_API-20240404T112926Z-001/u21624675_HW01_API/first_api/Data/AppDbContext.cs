﻿using first_api.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace first_api.Data
{
    public class AppDbContext : DbContext 
    {
        // INITIALIZATION
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }


        // Set Your Tables Here 

        public DbSet<CourseListing> CourseListing { get; set; }



        // run default constructor method

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);


            // Seed dummy Data
            var courses = new CourseListing[]
            {
                new CourseListing {
                                     courseId = 1 ,
                                     courseName = "AIM 101",
                                     courseDescription = "Basic Computer Knowledge",
                                     
                                  },
                new CourseListing {
                                     courseId = 2 ,
                                     courseName = "INF 354",
                                     courseDescription = "3rd year Advanced Programming",
                                  },
                new CourseListing {
                                     courseId = 3 ,
                                     courseName = "INF 272",
                                     courseDescription = "2nd year Advanced Programming",
                                  },
                new CourseListing {
                                     courseId = 4 ,
                                     courseName = "INF 154",
                                     courseDescription = "1st year Advanced programming(Sem 1)",
                                  },
                new CourseListing {
                                     courseId = 5 ,
                                     courseName = "INF 164",
                                     courseDescription = "1st year Advanced programming(Sem 2)",
                        },
                 new CourseListing {
                                     courseId = 6 ,
                                     courseName = "OBS 310",
                                     courseDescription = "Final year business management(Sem 1)",
                                  },
                  new CourseListing {
                                     courseId = 7 ,
                                     courseName = "OBS 330",
                                     courseDescription = "Final year business management(Sem 2)",
                                  },
                   new CourseListing {
                                     courseId = 8 ,
                                     courseName = "INF 315",
                                     courseDescription = "Informatics",
                                  },
            };
            builder.Entity<CourseListing>().HasData(courses);






        }


    }
}

        


    


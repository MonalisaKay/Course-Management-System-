﻿using first_api.Interfaces;
using first_api.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace first_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {

        // Initialize Repo 
        private readonly ICoursesRepo _courseRepo;
        private readonly IConfiguration _configuration;
        public CourseController(ICoursesRepo courseRepo, IConfiguration configuration )
        {
            _courseRepo = courseRepo;
            _configuration = configuration;
        }

        [HttpGet]
        [Route("getAllCourses")]
        public async Task<IActionResult> GetAllCourses()
        {
           try
           {
                return Ok(await _courseRepo.GetAllCourses());
           }
           catch (Exception ex)
           {
                // Notify  Admins
                return BadRequest("An Error Occoured , Please Try Again Later");
           }
        }


        [HttpGet]
        [Route("getAllCourses/{courseId}")]
        public async Task<IActionResult> GetCourse(int courseId)
        {
            try
            {
                return Ok(await _courseRepo.GetCourse(courseId));
            }
            catch (Exception ex)
            {
                // Notify  Admins
                return BadRequest("An Error Occoured , Please Try Again Later");
            }
        }


        [HttpPost]
        [Route("addCourse")]
        public async Task<IActionResult> AddCourse([FromBody] CourseListing courseListing)
        {
            try
            {
                var message = "Successfully Added Course";
                var added = await _courseRepo.AddCourse(courseListing);
                if(!added)
                {
                    message = "Received Data but Failed to Add , Please check the time idk";
                }
                return Ok(message);
            }
            catch (Exception ex)
            {
                // Notify  Admins
                return BadRequest("An Error Occoured , Please Try Again Later");
            }
        }

        [HttpPost]
        [Route("updateCourse")]
        public async Task<IActionResult> updateCourse([FromBody] CourseListing courseListing)
        {
            try
            {
                var message = "Successfully Updated Gaming Console";
                var added = await _courseRepo.UpdateCourse(courseListing);
                if (!added)
                {
                    message = "Received Data but Failed to Update, Please check the time idk";
                }
                return Ok(message);
            }
            catch (Exception ex)
            {
                // Notify  Admins
                return BadRequest("An Error Occoured , Please Try Again Later");
            }
        }


        [HttpGet]
        [Route("deleteCourse/{courseListingId}")]
        public async Task<IActionResult> deleteCourse(int courseListingId)
        {
            try
            {
                var message = "Successfully Deleted Course";
                var added = await _courseRepo.DeleteCourse(courseListingId);
                if (!added)
                {
                    message = "Received Data but Failed to Delete";
                }
                return Ok(message);
            }
            catch (Exception ex)
            {
                // Notify  Admins
                return BadRequest("An Error Occoured , Please Try Again Later");
            }
        }





    }
}

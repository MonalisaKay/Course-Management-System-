﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace CoursesAPI.Migrations
{
    /// <inheritdoc />
    public partial class Seed01 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "CourseListing",
                columns: table => new
                {
                    courseId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    courseName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    courseDescription = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CourseListing", x => x.courseId);
                });

            migrationBuilder.InsertData(
                table: "CourseListing",
                columns: new[] { "courseId", "courseDescription", "courseName" },
                values: new object[,]
                {
                    { 1, "Basic Computer Knowledge", "AIM 101" },
                    { 2, "3rd year Advanced Programming", "INF 354" },
                    { 3, "2nd year Advanced Programming", "INF 272" },
                    { 4, "1st year Advanced programming(Sem 1)", "INF 154" },
                    { 5, "1st year Advanced programming(Sem 2)", "INF 164" },
                    { 6, "Final year business management(Sem 1)", "OBS 310" },
                    { 7, "Final year business management(Sem 2)", "OBS 330" },
                    { 8, "Informatics", "INF 315" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CourseListing");
        }
    }
}

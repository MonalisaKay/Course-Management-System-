﻿using System.ComponentModel.DataAnnotations;

namespace first_api.Models
{
    public class CourseListing
    {
        [Key]
        public int courseId { get; set; }
        public string courseName { get; set; }
        
        public string courseDescription { get; set; }
    }
}

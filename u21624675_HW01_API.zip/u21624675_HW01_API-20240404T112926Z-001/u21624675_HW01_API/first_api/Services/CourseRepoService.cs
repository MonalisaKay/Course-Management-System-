﻿using first_api.Data;
using first_api.Interfaces;
using first_api.Models;
using Microsoft.EntityFrameworkCore;

namespace first_api.Services
{
    public class CourseRepoService : ICoursesRepo
    {

        // Initialize Repo 
        private readonly AppDbContext _db;
        public CourseRepoService(AppDbContext db)
        {
            _db = db;
        }
        public async Task<bool> AddCourse(CourseListing courseListing)
        {
            try
            {
                _db.CourseListing.AddAsync(courseListing);
                await _db.SaveChangesAsync();
            } catch (Exception ex)
            {
                return false;
            }
            return true;
        }
        public async Task<List<CourseListing>> GetAllCourses()
        {
            return await _db.CourseListing.ToListAsync();
        }
        public async Task<CourseListing> GetCourse(int courseListingId)
        {
            return await _db.CourseListing.Where(x=> x.courseId == courseListingId).FirstOrDefaultAsync();
        }
        public async Task<bool> UpdateCourse(CourseListing courseListing)
        {
            try
            {
                _db.CourseListing.Update(courseListing);
                await _db.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }
        public async Task<bool> DeleteCourse(int courseListingId)
        {
            try
            {
                var course = await GetCourse(courseListingId);
                _db.CourseListing.Remove(course);
                await _db.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }

    }
}

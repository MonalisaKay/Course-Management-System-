import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http'
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavComponent } from './nav/nav.component';
import { CourseListComponent } from './consoles/course-list/course-list.component';
import { CourseAddComponent } from './consoles/course-add/course-add.component';
import { CourseUpdateComponent } from './consoles/course-update/course-update.component';

@NgModule({
  declarations: [
    AppComponent,
    NavComponent,
    CourseListComponent,
    CourseAddComponent,
    CourseUpdateComponent
  ],
  imports: [
    FormsModule, 
    ReactiveFormsModule,
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

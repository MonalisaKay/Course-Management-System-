import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CourseListing } from '../classes/CourseListing';

@Injectable({
  providedIn: 'root'
})
export class CourseService {

  constructor(private http:HttpClient) { }
  endPoint:string = "https://localhost:44370/api/Course/";


  GetAllCourses()
  {

    return this.http.get<CourseListing[]>(this.endPoint + "getAllCourses");
  }
  GetCourse(courseId:number)
  {
    return this.http.get<CourseListing>(this.endPoint + `getAllCourses/${courseId}`);
  }


  
  AddCourse(CourseListing:CourseListing)
  {
    return this.http.post<string>(this.endPoint + "addCourse",CourseListing);
  }

  
  UpdateCourse(CourseListing:CourseListing)
  {
    return this.http.post<string>(this.endPoint + "updateCourse",CourseListing);
  }
 
  
  DeleteCourse(courseId:number)
  {
    return this.http.get<string>(this.endPoint + `deleteCourse/${courseId}`);
  }


}












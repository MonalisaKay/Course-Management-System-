import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CourseListComponent } from './consoles/course-list/course-list.component';
import { CourseAddComponent } from './consoles/course-add/course-add.component';
import { CourseUpdateComponent } from './consoles/course-update/course-update.component';

const routes: Routes = [
  {path: '', pathMatch:'full', redirectTo: 'home'},
  {path: 'home', component:CourseListComponent},
  {path: 'update/:courseId', component:CourseUpdateComponent},
  {path: 'add', component:CourseAddComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

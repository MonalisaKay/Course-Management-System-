import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { CourseListing } from 'src/app/classes/CourseListing';
import { CourseService } from 'src/app/services/courses.service';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-course-update',
  templateUrl: './course-update.component.html',
  styleUrls: ['./course-update.component.css']
})
export class CourseUpdateComponent {

  // Construct the Form 
  updateForm : FormGroup = new FormGroup({
    courseName : new FormControl("",[Validators.required]),
    courseDescription : new FormControl("",[Validators.required]),
  })

  IncomingData!:Subscription;
  courseId!: number;
  course!:CourseListing;


  constructor (private courseService:CourseService, private unknown:Router, private activatedRoute:ActivatedRoute) {}


  ngOnInit()
  {
    this.IncomingData = this.activatedRoute.params.subscribe(parms => {
      this.courseId = parms["consoleId"];
      this.fetchCourse();    
  });  
  }

  fetchCourse()
  {
    this.courseService.GetCourse(this.courseId).subscribe({
      next: res => {
        console.log(res);
        this.clearForm();
        this.course = res;
        this.assignValues();
      },
      error: err => {
        console.log(err);
      }  
    });

  }
  assignValues()
  {
    this.updateForm.controls["courseName"].setValue(this.course.courseName);
    this.updateForm.controls["courseDescription"].setValue(this.course.courseDescription);
  }


  clearForm()
  {
    this.updateForm.reset();
  }

  onUpdate()
  {
    // Collect the form data 
    if(this.updateForm.invalid)
    {
      Object.values(this.updateForm.controls).forEach(control => {
        if (control.invalid) {
          control.markAsDirty();
          control.updateValueAndValidity({ onlySelf: true });
        }
      });
    }
    else
    {
      let courseListing = new CourseListing();
      courseListing.courseName = this.updateForm.controls["courseName"].value;
      courseListing.courseDescription = this.updateForm.controls["courseDescription"].value;
      this.courseService.UpdateCourse(courseListing).subscribe({
        next: res => {
          console.log(res);
          this.clearForm();
          this.unknown.navigateByUrl("/home");
        },
        error: err => {
          console.log(err);
        }  
      });
    }
  }

  onCancel()
  {
    this.unknown.navigateByUrl("/home");
  }

}
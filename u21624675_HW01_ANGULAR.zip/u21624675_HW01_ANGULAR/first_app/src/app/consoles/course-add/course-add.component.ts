import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { CourseListing } from 'src/app/classes/CourseListing';
import { CourseService } from 'src/app/services/courses.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-course-add',
  templateUrl: './course-add.component.html',
  styleUrls: ['./course-add.component.css']
})
export class CourseAddComponent {

  // Construct the Form 
  addForm : FormGroup = new FormGroup({
    courseName : new FormControl("",[Validators.required]),
    courseDescription : new FormControl("",[Validators.required]),
  })
  constructor (private courseService:CourseService, private unknown:Router) {}


  ngOnInit()
  {
     this.clearForm();
  }

  clearForm()
  {
    this.addForm.reset();
  }
  onAdd()
  {
    // Collect the form data 
    if(this.addForm.invalid)
    {
      Object.values(this.addForm.controls).forEach(control => {
        if (control.invalid) {
          control.markAsDirty();
          control.updateValueAndValidity({ onlySelf: true });
        }
      });
    }
    else
    {
      let courseListing = new CourseListing();
      courseListing.courseName = this.addForm.controls["courseName"].value;
      courseListing.courseDescription = this.addForm.controls["courseDescription"].value;
      this.courseService.AddCourse(courseListing).subscribe({
        next: res => {
          this.clearForm();
          this.onCancel();
        },
        error: err => {
          console.log(err);
        }  
      });
    }
  }

  onCancel()
  {
    this.unknown.navigateByUrl("/home");
  }





}


export class CourseListing

{
    courseId!: number
    courseName!: string
    courseDescription!: string
    
}